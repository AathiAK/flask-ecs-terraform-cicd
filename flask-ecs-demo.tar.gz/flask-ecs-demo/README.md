# Flask ECS EC2 with GitHub Actions CI/CD

Automatic deployment to ECS EC2 on every push to GitHub!

## 🎯 What This Does

Push code → GitHub Actions automatically:
1. Builds Docker image
2. Pushes to ECR
3. Updates ECS task definition
4. Deploys new containers
5. Runs health checks

## 🚀 Quick Setup (4 Steps)

### Step 1: Deploy Infrastructure (One-time)


cd terraform
cp terraform.tfvars.example terraform.tfvars
vim terraform.tfvars  # Set vpc_id and key_name

terraform init
terraform apply -auto-approve


### Step 2: Initial Build & Deploy


cd ..
 scripts/build-and-push.sh
 scripts/deploy-ecs.sh


### Step 3: Add GitHub Secrets

Go to: GitHub Repository → Settings → Secrets → Actions

Add these secrets:
- `AWS_ACCESS_KEY_ID`: Your AWS access key
- `AWS_SECRET_ACCESS_KEY`: Your AWS secret key

Get keys:

aws iam create-access-key --user-name your-username


### Step 4: Push to GitHub


git init
git add .
git commit -m "Initial commit with CI/CD"
git remote add origin https://github.com/yourusername/your-repo.git
git branch -M main
git push -u origin main


Done! Now every push to main branch deploys automatically! 🎉

## 🔄 Development Workflow

### Make Changes


# 1. Edit code
vim docker/app.py

# 2. Commit and push
git add .
git commit -m "Updated app"
git push origin main


### GitHub Actions Automatically:
- Builds Docker image
- Pushes to ECR
- Deploys to ECS
- Runs tests
- Notifies you

### Monitor Deployment

1. Go to GitHub → Actions tab
2. Watch real-time deployment logs
3. See success/failure status

### Test Deployed App


# Get IPs
 scripts/get-instance-ips.sh

# Or manually
IP=$(aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=flask-demo-ecs-instance" \
            "Name=instance-state-name,Values=running" \
  --query 'Reservations[0].Instances[0].PublicIpAddress' \
  --output text)

# Test
curl http://$IP:5000/
curl http://$IP:5000/health


## 📋 Files Structure


.
├── .github/workflows/
│   └── deploy.yml           # GitHub Actions CI/CD pipeline
├── docker/
│   ├── Dockerfile
│   ├── app.py
│   └── requirements.txt
├── terraform/
│   └── main.tf             # Infrastructure (ECS, ECR, etc.)
├── scripts/
│   ├── build-and-push.sh
│   ├── deploy-ecs.sh
│   └── get-instance-ips.sh
└── README.md


## 🎬 How It Works


Push to GitHub (main branch)
        ↓
GitHub Actions Triggered
        ↓
Build Docker Image
        ↓
Push to Amazon ECR
        ↓
Update ECS Task Definition
        ↓
Deploy to ECS Service
        ↓
Health Check
        ↓
✅ Deployment Complete!


## 🐛 Troubleshooting

### Deployment Failed

Check GitHub Actions:
- Go to Actions tab
- Click failed run
- View error logs

Common Issues:

| Issue | Solution |
|-------|----------|
| AWS auth failed | Check GitHub Secrets |
| Task def not found | Run initial manual deploy first |
| Health check failed | Check app logs |

Debug Commands:


# Check ECS
aws ecs describe-services --cluster flask-demo-cluster --services flask-demo-service

# Check logs
aws logs tail /ecs/flask-demo --follow

# Manual deploy
 scripts/deploy-ecs.sh


## 📊 GitHub Workflow Configuration

Edit `.github/workflows/deploy.yml`:

yaml
env:
  AWS_REGION: us-east-1
  ECR_REPOSITORY: flask-demo
  ECS_CLUSTER: flask-demo-cluster
  ECS_SERVICE: flask-demo-service


Triggers:
- Push to `main` (automatic)
- Push to `develop` (automatic)
- Manual trigger (workflow_dispatch)

## 🔐 Security

### IAM Permissions Needed

json
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Action": [
      "ecr:",
      "ecs:DescribeTaskDefinition",
      "ecs:RegisterTaskDefinition",
      "ecs:UpdateService",
      "ecs:DescribeServices",
      "ec2:DescribeInstances"
    ],
    "Resource": ""
  }]
}


### Best Practices

✅ Use GitHub Secrets for AWS credentials
✅ Create dedicated IAM user for CI/CD
✅ Use least privilege permissions
✅ Rotate credentials regularly
❌ Never commit AWS keys to git

## 💡 Tips

1. Test locally first: Build Docker image locally before pushing
2. Use feature branches: Merge to main when ready to deploy
3. Monitor deployments: Watch GitHub Actions logs
4. Health checks: Ensure `/health` endpoint works
5. Rollback: Revert git commit if deployment fails

## 📈 What Gets Deployed

Every push to `main`:
- Docker image tagged with commit SHA
- Image also tagged as `latest`
- ECS service updated with new image
- Old containers gracefully terminated
- New containers started
- Health checks validated

## ✅ Checklist

Initial Setup:
- [ ] Infrastructure deployed
- [ ] Initial image pushed to ECR
- [ ] ECS service running
- [ ] GitHub Secrets configured
- [ ] First push triggers deployment

Every Deployment:
- [x] Code changes committed
- [x] Pushed to main
- [x] GitHub Actions triggered
- [x] Docker build succeeds
- [x] ECR push succeeds
- [x] ECS updated
- [x] Health check passes

## 🎓 Learn More

- [GitHub Actions Docs](https://docs.github.com/en/actions)
- [AWS ECS Docs](https://docs.aws.amazon.com/ecs/)
- [Docker Best Practices](https://docs.docker.com/develop/dev-best-practices/)

---

Push code. Deploy automatically. That simple! 🚀
